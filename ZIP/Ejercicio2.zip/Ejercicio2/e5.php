<?php

$n;
$pir = "o";

for ($n = 1; $n <= 10; $n++){
    echo $pir . "<br>";
    $pir = $pir . "o";
    
}

?>