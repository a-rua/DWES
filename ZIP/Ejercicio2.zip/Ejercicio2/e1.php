<?php

$n = 0;

while ($n != 100) {
    $n++;
    echo $n . " ";
}

?>