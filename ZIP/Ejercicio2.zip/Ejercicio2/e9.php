<?php

$t = $_GET["tabla"];

for ($z = 0; $z <= 10; $z++ ) {
    echo $z * $t . "<br>";
}

?>