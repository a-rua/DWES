<?php

$n = 0;

while ($n != 100) {
    $n++;
        if ($n %2 == 0) {
        echo $n . " ";
    }
}

?>